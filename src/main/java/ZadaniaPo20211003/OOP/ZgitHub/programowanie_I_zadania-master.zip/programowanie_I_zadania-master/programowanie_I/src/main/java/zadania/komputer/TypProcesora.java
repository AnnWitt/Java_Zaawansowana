package zadania.komputer;

public enum TypProcesora {
    WIELORDZENIOWY,
    JEDNORDZENIOWY
}
