package zadania.autostrada;
/**
 * To rozwiązanie opiera sie na kodzie stworzonym przez Pawła Recława, many thanks!
 *
 * @author Paweł Recław
 */
public enum TypPojazdu {
    OSOBOWY, CIEZAROWY, MOTOCYKL
}