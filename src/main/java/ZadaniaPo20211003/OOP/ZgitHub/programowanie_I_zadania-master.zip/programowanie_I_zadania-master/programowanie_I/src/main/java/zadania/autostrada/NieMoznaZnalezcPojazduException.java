package zadania.autostrada;
/**
 * To rozwiązanie opiera sie na kodzie stworzonym przez Pawła Recława, many thanks!
 *
 * @author Paweł Recław
 */
public class NieMoznaZnalezcPojazduException extends RuntimeException {
}