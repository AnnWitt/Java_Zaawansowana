package zadania.robot;

public class Main {
    /**
     * To rozwiązanie opiera sie na kodzie stworzonym przez Eweline Fiedorowicz, many thanks!
     *
     * @author Ewelina Fiedorowicz
     */
    public static void main(String[] args) {
        Robot nexus6 = new Robot("Roy Batty");
        nexus6.przedstawRobota();
    }
}
