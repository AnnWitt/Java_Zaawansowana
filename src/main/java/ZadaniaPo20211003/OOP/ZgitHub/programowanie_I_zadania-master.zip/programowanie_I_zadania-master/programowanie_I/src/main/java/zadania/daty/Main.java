package zadania.daty;

public class Main {
    public static void main(String[] args) {
        MojaData mojaData = new MojaData(1,11,2011);

        mojaData.wyswietlDate();
        mojaData.wyswietlDate2();
        mojaData.wyswietlDate3();




    }
}
